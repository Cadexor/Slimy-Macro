﻿#Requires AutoHotkey v2.0

CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"
SendMode "Event"
SetDefaultMouseSpeed 10
; Press F3 to find and click the button
F1::RunMacro()

F2::ExitApp

F3::SaveSettings()

iniFile := A_ScriptDir "\settings.ini"
savedBuyZone := IniRead(iniFile, "Settings", "BuyZone", 0)
savedRebirth := IniRead(iniFile, "Settings", "Rebirth", 0)
savedUseGun := IniRead(iniFile, "Settings", "UseGun", 0)
savedEquipBest := IniRead(iniFile, "Settings", "EquipBest", 0)


myGui := Gui()
myGui.Title := "Slimy Macro"

;Controls
myGui.Add("Text", "w250 center", "Slimy Macro by Dywn")
myGui.Add("Text", "w250 center", "F1: Start Macro")
myGui.Add("Text", "w250 center", "F2: Exit Macro")
myGui.Add("Text", "w250 center", "F3: Save Settings")
myGui.Add("Text", "w250 Center", "Select tasks to enable:")

myGui.Add("Checkbox", "vBuyZone y+15" (savedBuyZone ? " Checked" : ""), "Enable Buying Zone")
myGui.Add("Checkbox", "vRebirth y+10" (savedRebirth ? " Checked" : ""), "Enable Rebirthing")
myGui.Add("Checkbox", "vUseGun y+10" (savedUseGun ? " Checked" : ""), "Enable Use Gun")
myGui.Add("Checkbox", "vEquipBest y+10" (savedEquipBest ? " Checked" : ""), "Enable Equip Best")
myGui.Add("Text", "w250 Center", "Settings will be saved when you start the macro or click 'Save Settings'")

myGui.Add("Button", "w250 Default y+20", "Start").OnEvent("Click", RunMacro)
myGui.Add("Button", "w250 Default y+20", "Save Settings").OnEvent("Click", SaveSettings)


myGui.Show()

SaveSettings(*){
    Saved := myGui.Submit(false) ; Get the current state of the Checkboxes
    IniWrite(Saved.BuyZone, iniFile, "Settings", "BuyZone")
    IniWrite(Saved.Rebirth, iniFile, "Settings", "Rebirth")
    IniWrite(Saved.UseGun, iniFile, "Settings", "UseGun")
    IniWrite(saved.EquipBest, iniFile, "Settings", "EquipBest")
}
; --- Function Logic ---

RunMacro(*) {
    Click(1435,872)
    Sleep 100
    SaveSettings() ; Save settings before running the macro
    if (myGui.Submit(false).Rebirth) {
        FindAndRebirth()
    }
    if (myGui.Submit(false).BuyZone) {
        FindAndBuyZone()
    }
    if (myGui.Submit(false).EquipBest) {
        EquipBest()
    }
    if (myGui.Submit(false).UseGun) {
        loop 10{
            UseGun()
        }
    } 
    RunMacro() ; Loop the macro
}





FindAndRebirth(){
    MouseMove(1831, 443, 10)
    Sleep 500
    Click() ; click to open rebirth menu
    Sleep 500
    MouseMove(1269, 757, 10)
    Sleep 500
    Click() ; click to rebirth
    if ImageSearch(&FoundX, &FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*100 assets/rebirth_stat.png") {
        MouseMove(1492,221,10)
        Sleep 500
        Click() ; click to exit rebirth menu
    }else{
        return
    }
}

FindAndBuyZone(){
    MouseMove(1832,752,10)
    Sleep 500
    Click()
    Sleep 500
BuyZoneLogic()
}

BuyZoneLogic(){
    if ImageSearch(&FoundX, &FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*100 assets/buy_area.png") {
        ClickX := FoundX + 40
        ClickY := FoundY + 20
        MouseMove(ClickX, ClickY, 10)
        Sleep 500
        Click() ; click to buy zone
        Sleep 500
        Click() ; click to teleport
        sleep 500
        If ImageSearch(&IshereX, &IshereY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*100 assets/no_message.png") {
            MouseMove(1492,221,10)
            Sleep 500
            Click() ; click to exit teleport menu
            Sleep 500
        }else{
            BuyZoneLogic()
        }
    } else {
        ImageSearch(&FoundBarX, &FoundBarY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*10 assets/scroll_bar.png")
        if (FoundBarX != ""){
            MouseClickDrag("Left", FoundBarX + 15, FoundBarY + 0, FoundBarX + 35, FoundBarY + 500, 10)
            Sleep 1000
            ImageSearch(&FoundX, &FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*100 assets/buy_area.png")
            ClickX := FoundX + 40
            ClickY := FoundY + 20
            MouseMove(ClickX, ClickY, 10)
            Sleep 500
            Click() ; click to buy zone
            Sleep 500
            Click() ; click to teleport
            sleep 500
            MouseMove(1492,221,10)
            Sleep 500
            Click() ; click to exit teleport menu
            Sleep 500
        }
    }
}







UseGun(){
    MouseClickDrag("Left", 500, 500, 1500, 500, 100) ; Drag to use gun
    MouseClickDrag("Left", 1500, 500, 500, 500, 100) ; Drag back to original position
}

EquipBest(){
    Click(801,974)
    Sleep 500
    Click(1336,204)
    Sleep 500
    Click(1489,226)
}